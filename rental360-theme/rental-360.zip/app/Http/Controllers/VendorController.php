<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VendorController extends Controller
{
    public function vendorList()
    {  
    return view('front.vendor_list');   
    }
    public function vendorSave()
    {  
    return view('front.vendor_list');   
    } 






}
